export class Registro
{
  id: string;
  nombre: string;
  apellido: string;
  procesado: boolean;

  constructor(){}
}
